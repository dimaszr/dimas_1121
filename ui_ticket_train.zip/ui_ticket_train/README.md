# Slicing UI Train Ticket Booking

Latihan membuat UI Train Ticket Booking

## Screenshot
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_iu_train_ticket_booking/main/screenshot/dashboard.png" alt="" width="300">
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_iu_train_ticket_booking/main/screenshot/seat_picker.png" alt="" width="300">
<img src="https://raw.githubusercontent.com/riyanhadi/slicing_iu_train_ticket_booking/main/screenshot/booking_detail.png" alt="" width="300">

## Referensi Desain
[Train Ticket Booking Mobile App](https://dribbble.com/shots/21162464-Train-Ticket-Booking-Mobile-App)