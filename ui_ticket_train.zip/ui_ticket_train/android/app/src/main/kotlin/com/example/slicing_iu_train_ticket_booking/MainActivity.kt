package com.example.slicing_iu_train_ticket_booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
